function toggleMenu() {
  document.getElementById("navLinks").classList.toggle("show");
}
